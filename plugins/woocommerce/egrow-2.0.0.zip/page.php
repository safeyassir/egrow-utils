<?php

global $EGROW_API_KEY_OPTION;


if (isset($_POST["api_key"])) {
    update_option($EGROW_API_KEY_OPTION, $_POST["api_key"]);
    add_action("admin_notices", "egrow_save_success");
}

?>
<div class="wrap" dir="ltr">
    <h1>eGrow</h1>
    <?php do_action("admin_notices"); ?>
    <form method="POST">
        <input type="text" name="api_key" placeholder="API KEY" value="<?php echo get_option($EGROW_API_KEY_OPTION, ""); ?>" class="regular-text" />
        <input type="submit" class="button button-primary" value="Save"/>
    </form>
</div>

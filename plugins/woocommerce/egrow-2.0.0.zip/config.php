<?php

$BASE_URL = "https://apidev.egrow.com";
$EGROW_API_KEY_OPTION = 'egrow_access_token';

?>
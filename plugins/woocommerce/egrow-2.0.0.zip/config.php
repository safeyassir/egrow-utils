<?php

$BASE_URL = "https://api.egrow.com";
$EGROW_API_KEY_OPTION = 'egrow_access_token';

?>
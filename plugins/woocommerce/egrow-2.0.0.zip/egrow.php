<?php

/**
 * The plugin bootstrap file
 *
 * @link              https://www.egrow.com
 * @since             1.0.0
 * @package           eGrow Woocommerce
 *
 * @wordpress-plugin
 * Plugin Name:       eGrow Woocommerce
 * Plugin URI:        https://www.egrow.com
 * Description:       eGrow Plugin for WooCommerce
 * Version:           2.0.0
 * Author:            eGrow
 * Author URI:        https://www.egrow.com
 * License:           MIT
 * License URI:       https://opensource.org/licenses/MIT
 * Text Domain:       egrow
 */


require_once "config.php";

function handle_error($data, $apiKey, $e)
{
    $logger = wc_get_logger();

    $url = "https://failover.safe.ma/failover/add.php";

    $postFields = [
        'data' => json_encode($data),
        'fa_api_key' => $apiKey,
        'fa_error_res' => json_encode($e),
        'fa_utm_source' => 'Wordpress eGrow plugin'
    ];

    $curl = curl_init();

    $logger->info("failover Request", ['postFields' => $postFields]);

    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postFields); // Sending the POST fields as an array
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($curl);
    $logger->info("failover Response", ['response' => $response]);

    if ($response === false) {
        $error = curl_error($curl);
        $errorCode = curl_errno($curl);
        $logger->error("failover Error: $errorCode", ['error' => $error]);
    } else {
        $logger->error("failover Response", ['response' => $response]);
    }

    curl_close($curl);
}

function egrow_page()
{
    include_once "page.php";
}

function egrow_admin_menu()
{
    add_menu_page("eGrow", "eGrow", "read", "egrow", "egrow_page", "dashicons-chart-line");
}

function egrow_save_success()
{
    ?>
    <div class="notice notice-success is-dismissible">
        <p>Saved successfully!</p>
    </div>
    <?php
}

function egrow_process_order($orderId)
{
    global $BASE_URL;
    global $EGROW_API_KEY_OPTION;
    $logger = wc_get_logger();
    $apiKey = "";
    $order_data = [];

    try {
        if (($apiKey = get_option($EGROW_API_KEY_OPTION, "")) == "") return;
        if (get_post_meta($orderId, '_custom_order_processed', false)) {
            return;
        }

        $logger->info("WC get_data", ["orderId" => $orderId]);
        $order_data["orderId"] = $orderId;
        $order_data["shop"] = home_url('/');
       /* $order_city = $order_data["shipping"]["city"];
        $order_state = $order_data["shipping"]["state"];
        $order_country = $order_data["shipping"]["country"];
        if (empty($order_city)) {
            $order_city = $order_data["billing"]["city"];
        }

        if (empty($order_state)) {
            $order_state = $order_data["billing"]["state"];
        }

        if (empty($order_country)) {
            $order_country = $order_data["billing"]["country"];
        }

        $order_data["my_city"] = "";
        if (empty($order_city)) {
            if (!empty($order_country) && !empty($order_state)) {
                $order_data["my_city"] = WC()->countries->get_states($order_country)[$order_state];
            }
        } else {
            $order_data["my_city"] = $order_city;
        }

        $order_data['line_items'] = array();

        foreach ($order->get_items() as $item_id => $item_values) {
            // Get the product object
            $product = $item_values->get_product();

            // Prepare line item data
            $line_item = array(
                "id" => $item_id,
                "product_id" => $item_values->get_product_id(),
                "variation_id" => $item_values->get_variation_id(),
                "product_title" => $item_values->get_name(),
                "sku" => $product ? $product->get_sku() : '',
                "quantity" => $item_values->get_quantity(),
                "price" => $product ? $product->get_price() : 0,
                "total" => $item_values->get_total(),
                "subtotal" => $item_values->get_subtotal(),
                "tax_total" => $item_values->get_total_tax(),
                "subtotal_tax" => $item_values->get_subtotal_tax(),
                "meta_data" => array(),
            );

            // Retrieve metadata (custom fields associated with the item)
            foreach ($item_values->get_meta_data() as $meta) {
                $line_item['meta_data'][] = array(
                    'key' => $meta->get_data()['key'],
                    'value' => $meta->get_data()['value']
                );
            }

            // Add the line item to the order data
            $order_data['line_items'][] = $line_item;
        }*/

        $url = "$BASE_URL/app-woocommerce/add_woocommerce_order_v2.php?me=" . urlencode($apiKey);
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($order_data));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($curl);
        $logger->info("Egrow add_woocommerce_order response", ["response" => $response]);


        if ($response === false) {
            $error = curl_error($curl);
            $errorCode = curl_errno($curl);
            $logger->error("Egrow Failed: $errorCode", ['error' => $error]);
            handle_error($order_data, $apiKey, ['error' => $error, 'code' => $errorCode]);
        } else {
            $httpStatusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            if ($httpStatusCode >= 200 && $httpStatusCode < 300) {
                $responseData = json_decode($response, true);
                if($responseData["status"] == "success") {
                    $logger->info("add_woocommerce_order Successful", ['response' => $response]);
                    update_post_meta($orderId, '_custom_order_processed', true);
                } else {
                    $logger->error("add_woocommerce_order Failed", ['response' => $response]);
                    handle_error($order_data, $apiKey, $responseData);
                }

            } else {
                $e = ['httpStatusCode' => $httpStatusCode, 'response' => json_decode($response, true)];
                $logger->error("Egrow HTTP Error: $httpStatusCode",$e);
                handle_error($order_data, $apiKey, $e);
            }
        }

        curl_close($curl);


    } catch (Exception $e) {
        $logger->error("Exception !!!", ['exception' => $e->getMessage()]);
        handle_error($order_data, $apiKey, $e->getMessage());
    }
}

function egrow_process_new_product($postId, $post, $update)
{
    // Check if it's a product and not an update to an existing product
    if ($post->post_type !== 'product' || $update) {
        return;
    }

    global $BASE_URL;
    global $EGROW_API_KEY_OPTION;

    $logger = wc_get_logger();
    $apiKey = get_option($EGROW_API_KEY_OPTION, "");

    if (empty($apiKey)) return;

    // Get the product object
    $product = wc_get_product($postId);
    if (!$product) return;
    $productData = [];
    $productData["productId"] = $postId;
    $productData["shop"] = get_site_url();

    $logger->info("Egrow product_data", ["product_data" => $productData]);

    $url = "$BASE_URL/app-woocommerce/add_woocommerce_product.php?me=" . urlencode($apiKey);
    $curl = curl_init();



    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($productData));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($curl, CURLOPT_TIMEOUT, 30);
    $response = curl_exec($curl);
    $logger->info("Egrow add_woocommerce_product response", ["response" => $response]);

    if ($response === false) {
        $error = curl_error($curl);
        $errorCode = curl_errno($curl);
        $logger->error("Egrow Failed: $errorCode", ['error' => $error]);
        handle_error($productData, $apiKey, ['error' => $error, 'code' => $errorCode]);
    } else {
        $httpStatusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        if ($httpStatusCode >= 200 && $httpStatusCode < 300) {
            $responseData = json_decode($response, true);
            if ($responseData["status"] == "success") {
                $logger->info("add_woocommerce_product Successful", ['response' => $response]);
            } else {
                $logger->error("add_woocommerce_product Failed", ['response' => $response]);
                handle_error($productData, $apiKey, $responseData);
            }
        } else {
            $e = ['httpStatusCode' => $httpStatusCode, 'response' => json_decode($response, true)];
            $logger->error("Egrow HTTP Error: $httpStatusCode", $e);
            handle_error($productData, $apiKey, $e);
        }
    }

    curl_close($curl);
}

function egrow_start_updater()
{
    $logger = wc_get_logger();

    if (is_admin()) {

        define('GH_REQUEST_URI', 'https://api.github.com/repos/%s/%s/releases');
        define('GHPU_USERNAME', 'safeyassir');
        define('GHPU_REPOSITORY', 'egrow-woocommerce-plugin');
        define('GHPU_AUTH_TOKEN', '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');

        include_once plugin_dir_path(__FILE__) . '/GhPluginUpdater.php';

        $updater = new GhPluginUpdater(__FILE__);
        $updater->init();

        $logger->info("WC github_plugin_updater_test_init", ["github_plugin_updater_test_init" => plugin_dir_path(__FILE__) . '/GhPluginUpdater.php']);

    }
}

add_action("admin_menu", "egrow_admin_menu");
add_action("woocommerce_thankyou", "egrow_process_order");
add_action('save_post_product', 'egrow_process_new_product', 10, 3);
?>
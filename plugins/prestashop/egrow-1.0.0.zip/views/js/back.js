/**
* 2007-2025 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2025 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*
* Don't forget to prefix your containers with your own identifier
* to avoid any conflicts with others containers.
*/

$(document).ready(function() {
    // Function to add copy and visibility buttons to token field
    function addTokenControls($input) {
        var $wrapper = $input.parent();
        var $controls = $('<div class="token-controls"></div>');
        
        // Create copy button
        var $copyButton = $('<button type="button" class="btn btn-default" title="Copy"><i class="icon icon-copy"></i></button>');
        
        // Create visibility toggle button
        var $visibilityButton = $('<button type="button" class="btn btn-default" title="Show/Hide"><i class="icon icon-eye"></i></button>');
        
        $controls.css({
            'position': 'absolute',
            'right': '10px',
            'top': '50%',
            'transform': 'translateY(-50%)',
            'display': 'flex',
            'gap': '5px'
        });
        
        $copyButton.css({
            'padding': '5px 10px'
        });
        
        $visibilityButton.css({
            'padding': '5px 10px'
        });
        
        $wrapper.css('position', 'relative');
        $wrapper.append($controls);
        $controls.append($copyButton);
        $controls.append($visibilityButton);
        
        // Copy functionality
        $copyButton.on('click', function() {
            $input.select();
            document.execCommand('copy');
            
            // Show copied message
            var $copiedMsg = $('<span class="copied-msg">Copied!</span>');
            $copiedMsg.css({
                'position': 'absolute',
                'right': '50px',
                'top': '50%',
                'transform': 'translateY(-50%)',
                'background': '#2eacce',
                'color': 'white',
                'padding': '2px 5px',
                'border-radius': '3px',
                'font-size': '12px'
            });
            
            $wrapper.append($copiedMsg);
            setTimeout(function() {
                $copiedMsg.fadeOut(400, function() {
                    $(this).remove();
                });
            }, 1000);
        });
        
        // Visibility toggle functionality
        $visibilityButton.on('click', function() {
            if ($input.attr('type') === 'password') {
                $input.attr('type', 'text');
                $visibilityButton.find('i').removeClass('icon-eye').addClass('icon-eye-slash');
            } else {
                $input.attr('type', 'password');
                $visibilityButton.find('i').removeClass('icon-eye-slash').addClass('icon-eye');
            }
        });
    }

    // Add controls to both token fields
    addTokenControls($('#EGROW_USER_TOKEN'));
    addTokenControls($('#EGROW_API_TOKEN'));
});

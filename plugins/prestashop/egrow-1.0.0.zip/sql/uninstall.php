<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

// Delete configuration values
Configuration::deleteByName('EGROW_LIVE_MODE');
Configuration::deleteByName('EGROW_USER_TOKEN');

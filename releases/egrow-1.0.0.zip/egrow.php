<?php
/**
 * 2007-2025 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2025 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class Egrow extends Module
{
    protected $config_form = false;
    protected $api_url = 'https://apidev.egrow.com';

    public function __construct()
    {
        $this->name = 'egrow';
        $this->tab = 'administration';
        $this->version = '1.2.0';
        $this->author = 'eGrow';
        $this->need_instance = 1;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('eGrow PrestaShop Module');
        $this->description = $this->l('eGrow for PrestaShop is a PrestaShop extension that syncs orders from your PrestaShop store with the eGrow SaaS platform, providing seamless integration and data synchronization.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall the module ?');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => '99.99.99');
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('displayBackOfficeHeader') &&
            $this->registerHook('actionObjectOrderAddAfter') &&
            $this->registerHook('actionObjectOrderUpdateAfter') &&
            $this->registerHook('actionObjectProductAddAfter') &&
            $this->registerHook('actionObjectProductUpdateAfter') &&
            Configuration::updateValue('EGROW_LIVE_MODE', false) &&
            Configuration::updateValue('EGROW_USER_TOKEN', '') &&
            Configuration::updateValue('EGROW_API_TOKEN', '');
    }

    public function uninstall()
    {
        Configuration::deleteByName('EGROW_LIVE_MODE');
        Configuration::deleteByName('EGROW_USER_TOKEN');
        Configuration::deleteByName('EGROW_API_TOKEN');

        include(dirname(__FILE__).'/sql/uninstall.php');

        return parent::uninstall();
    }

    /**
     * Handle module upgrade
     */
    public function upgrade($version)
    {
        $sql_file = dirname(__FILE__).'/sql/upgrade/'.$version.'.sql';
        if (file_exists($sql_file)) {
            $sql = file_get_contents($sql_file);
            if ($sql) {
                $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
                $sql = str_replace('ENGINE_TYPE', _MYSQL_ENGINE_, $sql);
                $sql = str_replace('CHARSET_TYPE', 'utf8', $sql);
                $sql = str_replace('COLLATE_TYPE', 'utf8_general_ci', $sql);

                $sql = preg_split("/;\s*[\r\n]+/", $sql);
                foreach ($sql as $query) {
                    if (!empty($query)) {
                        if (!Db::getInstance()->execute(trim($query))) {
                            return false;
                        }
                    }
                }
            }
        }

        // Clear cache after upgrade
        Tools::clearCache();

        return true;
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        $output = '';

        // Display confirmation/error messages
        if (Tools::isSubmit('submitEgrowModule')) {
            $this->postProcess();

            if (isset($this->context->smarty->tpl_vars['confirmation'])) {
                $output .= $this->displayConfirmation($this->context->smarty->tpl_vars['confirmation']->value);
            }
            if (isset($this->context->smarty->tpl_vars['error'])) {
                $output .= $this->displayError($this->context->smarty->tpl_vars['error']->value);
            }
        }

        $this->context->smarty->assign('module_dir', $this->_path);
        $output .= $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');
        $output .= $this->renderForm();

        return $output;
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitEgrowModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'col' => 6,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-key"></i>',
                        'desc' => $this->l('Enter your eGrow token'),
                        'name' => 'EGROW_USER_TOKEN',
                        'label' => $this->l('eGrow Token'),
                        'required' => true,
                        'class' => 'fixed-width-xxl',
                        'autocomplete' => 'off'
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'EGROW_USER_TOKEN' => Tools::getValue('EGROW_USER_TOKEN', Configuration::get('EGROW_USER_TOKEN')),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $egrow_token = Tools::getValue('EGROW_USER_TOKEN');

        if (!empty($egrow_token)) {
            // Generate PrestaShop API token
            $prestashop_token = $this->generateApiToken();

            // Get store information
            $store_info = $this->getStoreInfo();

            // Send store information to eGrow API
            $response = $this->sendStoreInfoToApi($egrow_token, $prestashop_token, $store_info);

            if ($response && $response['status'] == 'success') {
                // Update configuration values
                Configuration::updateValue('EGROW_USER_TOKEN', $egrow_token);
                Configuration::updateValue('EGROW_API_TOKEN', $prestashop_token);

                $this->context->smarty->assign('confirmation', $this->l('Store has been successfully registered with eGrow.'));
            } else {
                $this->context->smarty->assign('error', $this->l('Failed to register store with eGrow. Please check your token.'));
            }
        } else {
            $this->context->smarty->assign('error', $this->l('Token cannot be empty.'));
        }
    }

    protected function generateApiToken()
    {
        try {
            PrestaShopLogger::addLog('eGrow: Starting API token generation', 1, null, 'Egrow', null, true);

            // Enable Webservice if not already enabled
            if (!Configuration::get('PS_WEBSERVICE')) {
                PrestaShopLogger::addLog('eGrow: Enabling Webservice', 1, null, 'Egrow', null, true);
                if (!Configuration::updateValue('PS_WEBSERVICE', 1)) {
                    PrestaShopLogger::addLog('eGrow: Failed to enable Webservice', 3, null, 'Egrow', null, true);
                    return false;
                }
            }

            // Create a new API key with specific permissions
            PrestaShopLogger::addLog('eGrow: Creating new WebserviceKey', 1, null, 'Egrow', null, true);
            $apiKey = new WebserviceKey();
            $apiKey->key = Tools::passwdGen(32);
            $apiKey->description = 'eGrow API Key';
            $apiKey->active = true;
            
            // Save the API key
            PrestaShopLogger::addLog('eGrow: Attempting to save API key', 1, null, 'Egrow', null, true);
            if (!$apiKey->save()) {
                PrestaShopLogger::addLog('eGrow: Failed to save API key: ' . print_r($apiKey->getErrors(), true), 3, null, 'Egrow', null, true);
                return false;
            }
            PrestaShopLogger::addLog('eGrow: API key saved successfully with ID: ' . $apiKey->id, 1, null, 'Egrow', null, true);

            // Define GET permissions for all available resources
            $permissions = array(
                'addresses' => array('GET' => true),
                'attachments' => array('GET' => true),
                'carriers' => array('GET' => true),
                'cart_rules' => array('GET' => true),
                'carts' => array('GET' => true),
                'categories' => array('GET' => true),
                'combinations' => array('GET' => true),
                'configurations' => array('GET' => true),
                'contacts' => array('GET' => true),
                'content_management_system' => array('GET' => true),
                'countries' => array('GET' => true),
                'currencies' => array('GET' => true),
                'customer_messages' => array('GET' => true),
                'customer_threads' => array('GET' => true),
                'customers' => array('GET' => true),
                'deliveries' => array('GET' => true),
                'employees' => array('GET' => true),
                'groups' => array('GET' => true),
                'guests' => array('GET' => true),
                'image_types' => array('GET' => true),
                'images' => array('GET' => true),
                'languages' => array('GET' => true),
                'manufacturers' => array('GET' => true),
                'messages' => array('GET' => true),
                'order_carriers' => array('GET' => true),
                'order_cart_rules' => array('GET' => true),
                'order_details' => array('GET' => true),
                'order_histories' => array('GET' => true),
                'order_invoices' => array('GET' => true),
                'order_payments' => array('GET' => true),
                'order_slip' => array('GET' => true),
                'order_states' => array('GET' => true),
                'orders' => array('GET' => true),
                'price_ranges' => array('GET' => true),
                'product_customization_fields' => array('GET' => true),
                'product_feature_values' => array('GET' => true),
                'product_features' => array('GET' => true),
                'product_option_values' => array('GET' => true),
                'product_options' => array('GET' => true),
                'product_suppliers' => array('GET' => true),
                'products' => array('GET' => true),
                'search' => array('GET' => true),
                'shop_groups' => array('GET' => true),
                'shop_urls' => array('GET' => true),
                'shops' => array('GET' => true),
                'specific_price_rules' => array('GET' => true),
                'specific_prices' => array('GET' => true),
                'states' => array('GET' => true),
                'stock_availables' => array('GET' => true),
                'stock_movement_reasons' => array('GET' => true),
                'stock_movements' => array('GET' => true),
                'stocks' => array('GET' => true),
                'stores' => array('GET' => true),
                'suppliers' => array('GET' => true),
                'supply_order_details' => array('GET' => true),
                'supply_order_histories' => array('GET' => true),
                'supply_order_receipt_histories' => array('GET' => true),
                'supply_order_states' => array('GET' => true),
                'supply_orders' => array('GET' => true),
                'tags' => array('GET' => true),
                'tax_rule_groups' => array('GET' => true),
                'tax_rules' => array('GET' => true),
                'taxes' => array('GET' => true),
                'translated_configurations' => array('GET' => true),
                'warehouse_product_locations' => array('GET' => true),
                'warehouses' => array('GET' => true),
                'weight_ranges' => array('GET' => true),
                'zones' => array('GET' => true)
            );
            
            // Set the permissions for the API key
            PrestaShopLogger::addLog('eGrow: Setting permissions for API key', 1, null, 'Egrow', null, true);
            if (!WebserviceKey::setPermissionForAccount($apiKey->id, $permissions)) {
                PrestaShopLogger::addLog('eGrow: Failed to set permissions for API key', 3, null, 'Egrow', null, true);
                return false;
            }

            // Create a new employee profile for the API user if it doesn't exist
            PrestaShopLogger::addLog('eGrow: Creating employee profile', 1, null, 'Egrow', null, true);
            $employee = new Employee();
            $employee->firstname = 'eGrow';
            $employee->lastname = 'API';
            $employee->email = 'api@egrow.com';
            $employee->passwd = Tools::encrypt(Tools::passwdGen(16));
            $employee->id_profile = _PS_ADMIN_PROFILE_;
            $employee->active = true;
            $employee->id_lang = (int)Configuration::get('PS_LANG_DEFAULT');
            $employee->default_tab = 1;
            $employee->bo_theme = 'default';
            $employee->bo_css = 'theme.css';
            $employee->bo_width = 0;
            $employee->bo_show_screencast = 0;
            $employee->preselect_date_range = 'day';
            $employee->bo_list_limit = 20;
            $employee->bo_order_by = 'id_order';
            $employee->bo_order_way = 'DESC';
            $employee->bo_show_help = 1;
            $employee->has_enabled_gravatar = 0;

            if (!$employee->save()) {
                PrestaShopLogger::addLog('eGrow: Failed to save employee: ' . print_r($employee->getErrors(), true), 3, null, 'Egrow', null, true);
                return false;
            }

            // Set shop association after saving
            $employee->associateTo((int)Context::getContext()->shop->id);

            // Associate the API key with the employee
            PrestaShopLogger::addLog('eGrow: Associating API key with employee', 1, null, 'Egrow', null, true);
            $apiKey->id_employee = $employee->id;
            if (!$apiKey->update()) {
                PrestaShopLogger::addLog('eGrow: Failed to update API key with employee ID', 3, null, 'Egrow', null, true);
                return false;
            }

            // Clear cache to ensure changes take effect
            PrestaShopLogger::addLog('eGrow: Clearing cache', 1, null, 'Egrow', null, true);
            Tools::clearCache();
            
            PrestaShopLogger::addLog('eGrow: API token generation completed successfully', 1, null, 'Egrow', null, true);
            return $apiKey->key;

        } catch (Exception $e) {
            PrestaShopLogger::addLog('eGrow: Exception during API token generation: ' . $e->getMessage(), 3, null, 'Egrow', null, true);
            PrestaShopLogger::addLog('eGrow: Stack trace: ' . $e->getTraceAsString(), 3, null, 'Egrow', null, true);
            return false;
        }
    }

    protected function getStoreInfo()
    {
        return array(
            'store_url' => $this->getStoreUrl()
        );
    }

    protected function getStoreUrl()
    {
        return Tools::getShopDomain(true);
    }

    protected function sendStoreInfoToApi($egrow_token, $prestashop_token, $store_info)
    {
        $ch = curl_init($this->api_url . '/app-prestashop/setup.php');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
            'egrow_token' => $egrow_token,
            'prestashop_token' => $prestashop_token,
            'store_url' => $this->getStoreUrl()
        )));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        // Log the API request details
        PrestaShopLogger::addLog('eGrow API Request: ' . json_encode(array(
                'endpoint' => $this->api_url . '/app-prestashop/setup.php',
                'store_url' => $this->getStoreUrl()
            )), 1, null, 'Egrow', null, true);

        // Log the API response
        PrestaShopLogger::addLog('eGrow API Response - HTTP Code: ' . $httpCode . ' - Response: ' . $response, 1, null, 'Egrow', null, true);

        if ($error) {
            PrestaShopLogger::addLog('eGrow API Error: ' . $error, 3, null, 'Egrow', null, true);
            return false;
        }

        if ($httpCode == 200) {
            $decoded_response = json_decode($response, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded_response;
            } else {
                PrestaShopLogger::addLog('eGrow API Error: Invalid JSON response - ' . json_last_error_msg(), 3, null, 'Egrow', null, true);
                return false;
            }
        }

        return false;
    }

    /**
     * Add the CSS & JavaScript files you want to be loaded in the BO.
     */
    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addJS($this->_path.'views/js/back.js');
            $this->context->controller->addCSS($this->_path.'views/css/back.css');

            // Add custom JavaScript for token visibility toggle
            $this->context->controller->addJS($this->_path.'views/js/token-toggle.js');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
    }

    public function hookActionObjectOrderAddAfter($params)
    {
        $order = $params['object'];
        $token = Configuration::get('EGROW_USER_TOKEN');

        if (empty($token)) {
            PrestaShopLogger::addLog('eGrow: No token configured', 3, null, 'Egrow', $order->id, true);
            return;
        }

        // Get order carrier for shipping number
        $orderCarrier = new OrderCarrier($order->getIdOrderCarrier());
        $shippingNumber = $orderCarrier->tracking_number;

        // Get carrier information
        $carrier = new Carrier($order->id_carrier);
        $carrierData = array(
            'id' => $carrier->id,
            'name' => $carrier->name,
            'delay' => $carrier->delay,
            'tracking_url' => $carrier->url
        );

        // Get customer information
        $customer = new Customer($order->id_customer);
        $customerData = array(
            'id' => $customer->id,
            'email' => $customer->email,
            'firstname' => $customer->firstname,
            'lastname' => $customer->lastname,
            'birthday' => $customer->birthday,
            'newsletter' => $customer->newsletter,
            'optin' => $customer->optin,
            'active' => $customer->active,
            'date_add' => $customer->date_add,
            'date_upd' => $customer->date_upd
        );

        // Get all order data
        $orderData = array(
            'id_order' => $order->id,
            'reference' => $order->reference,
            'id_shop' => $order->id_shop,
            'id_shop_group' => $order->id_shop_group,
            'id_carrier' => $order->id_carrier,
            'id_lang' => $order->id_lang,
            'id_customer' => $order->id_customer,
            'id_cart' => $order->id_cart,
            'id_currency' => $order->id_currency,
            'id_address_delivery' => $order->id_address_delivery,
            'id_address_invoice' => $order->id_address_invoice,
            'current_state' => $order->current_state,
            'secure_key' => $order->secure_key,
            'payment' => $order->payment,
            'module' => $order->module,
            'recyclable' => $order->recyclable,
            'gift' => $order->gift,
            'gift_message' => $order->gift_message,
            'mobile_theme' => $order->mobile_theme,
            'shipping_number' => $shippingNumber,
            'total_discounts' => $order->total_discounts,
            'total_discounts_tax_incl' => $order->total_discounts_tax_incl,
            'total_discounts_tax_excl' => $order->total_discounts_tax_excl,
            'total_paid' => $order->total_paid,
            'total_paid_tax_incl' => $order->total_paid_tax_incl,
            'total_paid_tax_excl' => $order->total_paid_tax_excl,
            'total_paid_real' => $order->total_paid_real,
            'total_products' => $order->total_products,
            'total_products_wt' => $order->total_products_wt,
            'total_shipping' => $order->total_shipping,
            'total_shipping_tax_incl' => $order->total_shipping_tax_incl,
            'total_shipping_tax_excl' => $order->total_shipping_tax_excl,
            'carrier_tax_rate' => $order->carrier_tax_rate,
            'total_wrapping' => $order->total_wrapping,
            'total_wrapping_tax_incl' => $order->total_wrapping_tax_incl,
            'total_wrapping_tax_excl' => $order->total_wrapping_tax_excl,
            'round_mode' => $order->round_mode,
            'round_type' => $order->round_type,
            'conversion_rate' => $order->conversion_rate,
            'invoice_number' => $order->invoice_number,
            'delivery_number' => $order->delivery_number,
            'invoice_date' => $order->invoice_date,
            'delivery_date' => $order->delivery_date,
            'valid' => $order->valid,
            'date_add' => $order->date_add,
            'date_upd' => $order->date_upd,
            'note' => $order->note,
            'customer' => $customerData,
            'address' => array(
                'delivery' => $this->getAddressData($order->id_address_delivery),
                'invoice' => $this->getAddressData($order->id_address_invoice)
            ),
            'carrier' => $carrierData,
            'products' => $this->getOrderProducts($order),
            'order_payments' => $this->getOrderPayments($order)
        );

        PrestaShopLogger::addLog('eGrow: Sending order #' . $order->id . ' to API', 1, null, 'Egrow', $order->id, true);

        // Send to API
        $ch = curl_init($this->api_url . '/app-prestashop/create_order.php');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
            'token' => $token,
            'order' => $orderData,
            'store_url' => $this->getStoreUrl()
        )));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            PrestaShopLogger::addLog('eGrow: API Error - ' . $error, 3, null, 'Egrow', $order->id, true);
            return;
        }

        if ($httpCode != 200) {
            PrestaShopLogger::addLog('eGrow: API returned HTTP code ' . $httpCode . ' - Response: ' . $response, 3, null, 'Egrow', $order->id, true);
            return;
        }

        PrestaShopLogger::addLog('eGrow: Successfully sent order #' . $order->id . ' to API. Response: ' . $response, 1, null, 'Egrow', $order->id, true);
    }

    public function hookActionObjectOrderUpdateAfter($params)
    {
        $order = $params['object'];
        $token = Configuration::get('EGROW_USER_TOKEN');

        if (empty($token)) {
            PrestaShopLogger::addLog('eGrow: No token configured', 3, null, 'Egrow', $order->id, true);
            return;
        }

        // Get order carrier for shipping number
        $orderCarrier = new OrderCarrier($order->getIdOrderCarrier());
        $shippingNumber = $orderCarrier->tracking_number;

        // Get carrier information
        $carrier = new Carrier($order->id_carrier);
        $carrierData = array(
            'id' => $carrier->id,
            'name' => $carrier->name,
            'delay' => $carrier->delay,
            'tracking_url' => $carrier->url
        );

        // Get customer information
        $customer = new Customer($order->id_customer);
        $customerData = array(
            'id' => $customer->id,
            'email' => $customer->email,
            'firstname' => $customer->firstname,
            'lastname' => $customer->lastname,
            'birthday' => $customer->birthday,
            'newsletter' => $customer->newsletter,
            'optin' => $customer->optin,
            'active' => $customer->active,
            'date_add' => $customer->date_add,
            'date_upd' => $customer->date_upd
        );

        // Get all order data
        $orderData = array(
            'id_order' => $order->id,
            'reference' => $order->reference,
            'id_shop' => $order->id_shop,
            'id_shop_group' => $order->id_shop_group,
            'id_carrier' => $order->id_carrier,
            'id_lang' => $order->id_lang,
            'id_customer' => $order->id_customer,
            'id_cart' => $order->id_cart,
            'id_currency' => $order->id_currency,
            'id_address_delivery' => $order->id_address_delivery,
            'id_address_invoice' => $order->id_address_invoice,
            'current_state' => $order->current_state,
            'secure_key' => $order->secure_key,
            'payment' => $order->payment,
            'module' => $order->module,
            'recyclable' => $order->recyclable,
            'gift' => $order->gift,
            'gift_message' => $order->gift_message,
            'mobile_theme' => $order->mobile_theme,
            'shipping_number' => $shippingNumber,
            'total_discounts' => $order->total_discounts,
            'total_discounts_tax_incl' => $order->total_discounts_tax_incl,
            'total_discounts_tax_excl' => $order->total_discounts_tax_excl,
            'total_paid' => $order->total_paid,
            'total_paid_tax_incl' => $order->total_paid_tax_incl,
            'total_paid_tax_excl' => $order->total_paid_tax_excl,
            'total_paid_real' => $order->total_paid_real,
            'total_products' => $order->total_products,
            'total_products_wt' => $order->total_products_wt,
            'total_shipping' => $order->total_shipping,
            'total_shipping_tax_incl' => $order->total_shipping_tax_incl,
            'total_shipping_tax_excl' => $order->total_shipping_tax_excl,
            'carrier_tax_rate' => $order->carrier_tax_rate,
            'total_wrapping' => $order->total_wrapping,
            'total_wrapping_tax_incl' => $order->total_wrapping_tax_incl,
            'total_wrapping_tax_excl' => $order->total_wrapping_tax_excl,
            'round_mode' => $order->round_mode,
            'round_type' => $order->round_type,
            'conversion_rate' => $order->conversion_rate,
            'invoice_number' => $order->invoice_number,
            'delivery_number' => $order->delivery_number,
            'invoice_date' => $order->invoice_date,
            'delivery_date' => $order->delivery_date,
            'valid' => $order->valid,
            'date_add' => $order->date_add,
            'date_upd' => $order->date_upd,
            'note' => $order->note,
            'customer' => $customerData,
            'address' => array(
                'delivery' => $this->getAddressData($order->id_address_delivery),
                'invoice' => $this->getAddressData($order->id_address_invoice)
            ),
            'carrier' => $carrierData,
            'products' => $this->getOrderProducts($order),
            'order_payments' => $this->getOrderPayments($order)
        );

        PrestaShopLogger::addLog('eGrow: Sending updated order #' . $order->id . ' to API', 1, null, 'Egrow', $order->id, true);

        // Send to API
        $ch = curl_init($this->api_url . '/app-prestashop/create_order.php');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
            'token' => $token,
            'order' => $orderData,
            'store_url' => $this->getStoreUrl()
        )));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            PrestaShopLogger::addLog('eGrow: API Error - ' . $error, 3, null, 'Egrow', $order->id, true);
            return;
        }

        if ($httpCode != 200) {
            PrestaShopLogger::addLog('eGrow: API returned HTTP code ' . $httpCode . ' - Response: ' . $response, 3, null, 'Egrow', $order->id, true);
            return;
        }

        PrestaShopLogger::addLog('eGrow: Successfully sent updated order #' . $order->id . ' to API. Response: ' . $response, 1, null, 'Egrow', $order->id, true);
    }

    protected function getAddressData($addressId)
    {
        $address = new Address($addressId);
        $country = new Country($address->id_country);
        $state = new State($address->id_state);

        return array(
            'id' => $address->id,
            'id_customer' => $address->id_customer,
            'id_manufacturer' => $address->id_manufacturer,
            'id_supplier' => $address->id_supplier,
            'id_warehouse' => $address->id_warehouse,
            'id_country' => $address->id_country,
            'id_state' => $address->id_state,
            'alias' => $address->alias,
            'company' => $address->company,
            'lastname' => $address->lastname,
            'firstname' => $address->firstname,
            'address1' => $address->address1,
            'address2' => $address->address2,
            'postcode' => $address->postcode,
            'city' => $address->city,
            'other' => $address->other,
            'phone' => $address->phone,
            'phone_mobile' => $address->phone_mobile,
            'vat_number' => $address->vat_number,
            'dni' => $address->dni,
            'date_add' => $address->date_add,
            'date_upd' => $address->date_upd,
            'deleted' => $address->deleted,
            'country' => $country->name,
            'state' => $state->name
        );
    }

    protected function getOrderProducts($order)
    {
        $products = array();
        $orderDetails = $order->getOrderDetailList();

        foreach ($orderDetails as $detail) {
            $product = new Product($detail['product_id']);
            $products[] = array(
                'id' => $detail['product_id'],
                'id_order_detail' => $detail['id_order_detail'],
                'product_id' => $detail['product_id'],
                'product_attribute_id' => $detail['product_attribute_id'],
                'product_name' => $detail['product_name'],
                'product_quantity' => $detail['product_quantity'],
                'product_quantity_in_stock' => $detail['product_quantity_in_stock'],
                'product_quantity_return' => $detail['product_quantity_return'],
                'product_quantity_refunded' => $detail['product_quantity_refunded'],
                'product_quantity_reinjected' => $detail['product_quantity_reinjected'],
                'product_price' => $detail['product_price'],
                'reduction_percent' => $detail['reduction_percent'],
                'reduction_amount' => $detail['reduction_amount'],
                'reduction_amount_tax_incl' => $detail['reduction_amount_tax_incl'],
                'reduction_amount_tax_excl' => $detail['reduction_amount_tax_excl'],
                'group_reduction' => $detail['group_reduction'],
                'product_quantity_discount' => $detail['product_quantity_discount'],
                'product_ean13' => $detail['product_ean13'],
                'product_upc' => $detail['product_upc'],
                'product_reference' => $detail['product_reference'],
                'product_supplier_reference' => $detail['product_supplier_reference'],
                'product_weight' => $detail['product_weight'],
                'tax_name' => $detail['tax_name'],
                'tax_rate' => $detail['tax_rate'],
                'tax_computation_method' => $detail['tax_computation_method'],
                'id_tax_rules_group' => $detail['id_tax_rules_group'],
                'ecotax' => $detail['ecotax'],
                'ecotax_tax_rate' => $detail['ecotax_tax_rate'],
                'discount_quantity_applied' => $detail['discount_quantity_applied'],
                'download_hash' => $detail['download_hash'],
                'download_nb' => $detail['download_nb'],
                'download_deadline' => $detail['download_deadline'],
                'unit_price_tax_incl' => $detail['unit_price_tax_incl'],
                'unit_price_tax_excl' => $detail['unit_price_tax_excl'],
                'total_price_tax_incl' => $detail['total_price_tax_incl'],
                'total_price_tax_excl' => $detail['total_price_tax_excl'],
                'total_shipping_price_tax_excl' => $detail['total_shipping_price_tax_excl'],
                'total_shipping_price_tax_incl' => $detail['total_shipping_price_tax_incl'],
                'purchase_supplier_price' => $detail['purchase_supplier_price'],
                'original_product_price' => $detail['original_product_price'],
                'original_wholesale_price' => $detail['original_wholesale_price']
            );
        }

        return $products;
    }

    protected function getOrderPayments($order)
    {
        $payments = array();
        $orderPayments = $order->getOrderPayments();

        foreach ($orderPayments as $payment) {
            $payments[] = array(
                'id' => $payment->id,
                'order_reference' => $payment->order_reference,
                'id_currency' => $payment->id_currency,
                'amount' => $payment->amount,
                'payment_method' => $payment->payment_method,
                'conversion_rate' => $payment->conversion_rate,
                'transaction_id' => $payment->transaction_id,
                'card_number' => $payment->card_number,
                'card_brand' => $payment->card_brand,
                'card_expiration' => $payment->card_expiration,
                'card_holder' => $payment->card_holder,
                'date_add' => $payment->date_add
            );
        }

        return $payments;
    }

    public function hookActionObjectProductAddAfter($params)
    {
        $product = $params['object'];
        $token = Configuration::get('EGROW_USER_TOKEN');

        if (empty($token)) {
            PrestaShopLogger::addLog('eGrow: No token configured for product sync', 3, null, 'Egrow', $product->id, true);
            return;
        }

        // Load the full product data
        $product = new Product($product->id, true, $this->context->language->id);
        if (!Validate::isLoadedObject($product)) {
            PrestaShopLogger::addLog('eGrow: Failed to load product #' . $product->id, 3, null, 'Egrow', $product->id, true);
            return;
        }

        // Get all product data
        $productData = array(
            'id' => $product->id,
            'id_manufacturer' => $product->id_manufacturer,
            'id_supplier' => $product->id_supplier,
            'id_category_default' => $product->id_category_default,
            'id_shop_default' => $product->id_shop_default,
            'id_tax_rules_group' => $product->id_tax_rules_group,
            'on_sale' => $product->on_sale,
            'online_only' => $product->online_only,
            'ean13' => $product->ean13,
            'upc' => $product->upc,
            'ecotax' => $product->ecotax,
            'quantity' => $product->quantity,
            'minimal_quantity' => $product->minimal_quantity,
            'price' => $product->price,
            'wholesale_price' => $product->wholesale_price,
            'unity' => $product->unity,
            'unit_price_ratio' => $product->unit_price_ratio,
            'additional_shipping_cost' => $product->additional_shipping_cost,
            'reference' => $product->reference,
            'supplier_reference' => $product->supplier_reference,
            'location' => $product->location,
            'width' => $product->width,
            'height' => $product->height,
            'depth' => $product->depth,
            'weight' => $product->weight,
            'out_of_stock' => $product->out_of_stock,
            'additional_delivery_times' => $product->additional_delivery_times,
            'quantity_discount' => $product->quantity_discount,
            'customizable' => $product->customizable,
            'uploadable_files' => $product->uploadable_files,
            'text_fields' => $product->text_fields,
            'active' => $product->active,
            'redirect_type' => $product->redirect_type,
            'id_product_redirected' => $product->id_product_redirected,
            'available_for_order' => $product->available_for_order,
            'available_date' => $product->available_date,
            'show_condition' => $product->show_condition,
            'condition' => $product->condition,
            'show_price' => $product->show_price,
            'indexed' => $product->indexed,
            'visibility' => $product->visibility,
            'cache_is_pack' => $product->cache_is_pack,
            'cache_has_attachments' => $product->cache_has_attachments,
            'is_virtual' => $product->is_virtual,
            'cache_default_attribute' => $product->cache_default_attribute,
            'date_add' => $product->date_add,
            'date_upd' => $product->date_upd,
            'advanced_stock_management' => $product->advanced_stock_management,
            'pack_stock_type' => $product->pack_stock_type,
            'state' => $product->state,
            'product_type' => $product->product_type,
            'name' => $product->name[$this->context->language->id],
            'description' => $product->description[$this->context->language->id],
            'description_short' => $product->description_short[$this->context->language->id],
            'link_rewrite' => $product->link_rewrite[$this->context->language->id],
            'meta_description' => $product->meta_description[$this->context->language->id],
            'meta_keywords' => $product->meta_keywords[$this->context->language->id],
            'meta_title' => $product->meta_title[$this->context->language->id],
            'available_now' => $product->available_now[$this->context->language->id],
            'available_later' => $product->available_later[$this->context->language->id],
            'categories' => $this->getProductCategories($product),
            'images' => $this->getProductImages($product),
            'features' => $this->getProductFeatures($product),
            'tags' => $this->getProductTags($product),
            'attributes' => $this->getProductAttributes($product)
        );

        PrestaShopLogger::addLog('eGrow: Sending product #' . $product->id . ' to API', 1, null, 'Egrow', $product->id, true);

        // Send to API
        $ch = curl_init($this->api_url . '/app-prestashop/create_product.php');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
            'token' => $token,
            'order' => $productData,
            'store_url' => $this->getStoreUrl()
        )));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            PrestaShopLogger::addLog('eGrow: API Error for product #' . $product->id . ' - ' . $error, 3, null, 'Egrow', $product->id, true);
            return;
        }

        if ($httpCode != 200) {
            PrestaShopLogger::addLog('eGrow: API returned HTTP code ' . $httpCode . ' for product #' . $product->id . ' - Response: ' . $response, 3, null, 'Egrow', $product->id, true);
            return;
        }

        PrestaShopLogger::addLog('eGrow: Successfully sent product #' . $product->id . ' to API. Response: ' . $response, 1, null, 'Egrow', $product->id, true);
    }

    protected function getProductCategories($product)
    {
        $categories = array();
        $productCategories = $product->getCategories();

        foreach ($productCategories as $categoryId) {
            $category = new Category($categoryId);
            $categories[] = array(
                'id' => $category->id,
                'name' => $category->name[$this->context->language->id],
                'link_rewrite' => $category->link_rewrite[$this->context->language->id],
                'description' => $category->description[$this->context->language->id],
                'meta_title' => $category->meta_title[$this->context->language->id],
                'meta_description' => $category->meta_description[$this->context->language->id],
                'meta_keywords' => $category->meta_keywords[$this->context->language->id]
            );
        }

        return $categories;
    }

    protected function getProductImages($product)
    {
        $images = array();
        $productImages = $product->getImages($this->context->language->id);

        foreach ($productImages as $image) {
            $images[] = array(
                'id' => $image['id_image'],
                'position' => $image['position'],
                'cover' => $image['cover'],
                'legend' => $image['legend'],
                'url' => _PS_IMG_DIR_ . 'p/' . $image['id_image'] . '.jpg'
            );
        }

        return $images;
    }

    protected function getProductFeatures($product)
    {
        $features = array();
        $productFeatures = $product->getFeatures();

        foreach ($productFeatures as $feature) {
            $features[] = array(
                'id_feature' => $feature['id_feature'],
                'id_feature_value' => $feature['id_feature_value'],
                'feature_name' => $feature['name'],
                'feature_value' => $feature['value']
            );
        }

        return $features;
    }

    protected function getProductTags($product)
    {
        $tags = array();
        $productTags = $product->getTags($this->context->language->id);

        foreach ($productTags as $tag) {
            $tags[] = $tag;
        }

        return $tags;
    }

    protected function getProductAttributes($product)
    {
        $attributes = array();
        $productAttributes = $product->getAttributesResume($this->context->language->id);

        foreach ($productAttributes as $attribute) {
            $attributes[] = array(
                'id_product_attribute' => $attribute['id_product_attribute'],
                'attribute_designation' => $attribute['attribute_designation'],
                'reference' => $attribute['reference'],
                'ean13' => $attribute['ean13'],
                'upc' => $attribute['upc'],
                'quantity' => $attribute['quantity'],
                'price' => $attribute['price'],
                'wholesale_price' => $attribute['wholesale_price'],
                'weight' => $attribute['weight'],
                'unit_price_impact' => $attribute['unit_price_impact'],
                'default_on' => $attribute['default_on'],
                'minimal_quantity' => $attribute['minimal_quantity']
            );
        }

        return $attributes;
    }

    public function hookActionObjectProductUpdateAfter($params)
    {
        $product = $params['object'];
        $token = Configuration::get('EGROW_USER_TOKEN');

        if (empty($token)) {
            PrestaShopLogger::addLog('eGrow: No token configured for product sync', 3, null, 'Egrow', $product->id, true);
            return;
        }

        // Load the full product data
        $product = new Product($product->id, true, $this->context->language->id);
        if (!Validate::isLoadedObject($product)) {
            PrestaShopLogger::addLog('eGrow: Failed to load product #' . $product->id, 3, null, 'Egrow', $product->id, true);
            return;
        }

        // Get all product data
        $productData = array(
            'id' => $product->id,
            'id_manufacturer' => $product->id_manufacturer,
            'id_supplier' => $product->id_supplier,
            'id_category_default' => $product->id_category_default,
            'id_shop_default' => $product->id_shop_default,
            'id_tax_rules_group' => $product->id_tax_rules_group,
            'on_sale' => $product->on_sale,
            'online_only' => $product->online_only,
            'ean13' => $product->ean13,
            'upc' => $product->upc,
            'ecotax' => $product->ecotax,
            'quantity' => $product->quantity,
            'minimal_quantity' => $product->minimal_quantity,
            'price' => $product->price,
            'wholesale_price' => $product->wholesale_price,
            'unity' => $product->unity,
            'unit_price_ratio' => $product->unit_price_ratio,
            'additional_shipping_cost' => $product->additional_shipping_cost,
            'reference' => $product->reference,
            'supplier_reference' => $product->supplier_reference,
            'location' => $product->location,
            'width' => $product->width,
            'height' => $product->height,
            'depth' => $product->depth,
            'weight' => $product->weight,
            'out_of_stock' => $product->out_of_stock,
            'additional_delivery_times' => $product->additional_delivery_times,
            'quantity_discount' => $product->quantity_discount,
            'customizable' => $product->customizable,
            'uploadable_files' => $product->uploadable_files,
            'text_fields' => $product->text_fields,
            'active' => $product->active,
            'redirect_type' => $product->redirect_type,
            'id_product_redirected' => $product->id_product_redirected,
            'available_for_order' => $product->available_for_order,
            'available_date' => $product->available_date,
            'show_condition' => $product->show_condition,
            'condition' => $product->condition,
            'show_price' => $product->show_price,
            'indexed' => $product->indexed,
            'visibility' => $product->visibility,
            'cache_is_pack' => $product->cache_is_pack,
            'cache_has_attachments' => $product->cache_has_attachments,
            'is_virtual' => $product->is_virtual,
            'cache_default_attribute' => $product->cache_default_attribute,
            'date_add' => $product->date_add,
            'date_upd' => $product->date_upd,
            'advanced_stock_management' => $product->advanced_stock_management,
            'pack_stock_type' => $product->pack_stock_type,
            'state' => $product->state,
            'product_type' => $product->product_type,
            'name' => $product->name[$this->context->language->id],
            'description' => $product->description[$this->context->language->id],
            'description_short' => $product->description_short[$this->context->language->id],
            'link_rewrite' => $product->link_rewrite[$this->context->language->id],
            'meta_description' => $product->meta_description[$this->context->language->id],
            'meta_keywords' => $product->meta_keywords[$this->context->language->id],
            'meta_title' => $product->meta_title[$this->context->language->id],
            'available_now' => $product->available_now[$this->context->language->id],
            'available_later' => $product->available_later[$this->context->language->id],
            'categories' => $this->getProductCategories($product),
            'images' => $this->getProductImages($product),
            'features' => $this->getProductFeatures($product),
            'tags' => $this->getProductTags($product),
            'attributes' => $this->getProductAttributes($product)
        );

        PrestaShopLogger::addLog('eGrow: Sending updated product #' . $product->id . ' to API', 1, null, 'Egrow', $product->id, true);

        // Send to API
        $ch = curl_init($this->api_url . '/app-prestashop/create_product.php');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
            'token' => $token,
            'order' => $productData,
            'store_url' => $this->getStoreUrl()
        )));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            PrestaShopLogger::addLog('eGrow: API Error for product #' . $product->id . ' - ' . $error, 3, null, 'Egrow', $product->id, true);
            return;
        }

        if ($httpCode != 200) {
            PrestaShopLogger::addLog('eGrow: API returned HTTP code ' . $httpCode . ' for product #' . $product->id . ' - Response: ' . $response, 3, null, 'Egrow', $product->id, true);
            return;
        }

        PrestaShopLogger::addLog('eGrow: Successfully sent updated product #' . $product->id . ' to API. Response: ' . $response, 1, null, 'Egrow', $product->id, true);
    }
}

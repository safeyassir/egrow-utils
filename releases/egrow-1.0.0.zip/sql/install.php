<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

// Create configuration values
Configuration::updateValue('EGROW_LIVE_MODE', false);
Configuration::updateValue('EGROW_USER_TOKEN', '');
Configuration::updateValue('EGROW_API_TOKEN', '');

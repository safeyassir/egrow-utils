#!/bin/bash

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PS_ROOT_DIR="$( cd "$SCRIPT_DIR/../.." && pwd )"

# Function to clear cache
clear_cache() {
    echo "Clearing cache..."
    
    # Clear Smarty cache
    if [ -d "$PS_ROOT_DIR/var/cache" ]; then
        rm -rf "$PS_ROOT_DIR/var/cache"/*
        echo "✓ Smarty cache cleared"
    fi

    # Clear module cache
    if [ -d "$PS_ROOT_DIR/var/cache/prod" ]; then
        rm -rf "$PS_ROOT_DIR/var/cache/prod"/*
        echo "✓ Module cache cleared"
    fi

    # Clear class index
    if [ -f "$PS_ROOT_DIR/var/cache/class_index.php" ]; then
        rm -f "$PS_ROOT_DIR/var/cache/class_index.php"
        echo "✓ Class index cleared"
    fi
}

# Function to install module
install_module() {
    echo "Installing module..."
    
    # Get module ID
    MODULE_ID=$(mysql -u root -e "SELECT id_module FROM ps_module WHERE name = 'egrow';" | tail -n 1)
    
    if [ -z "$MODULE_ID" ]; then
        # Module not installed, install it
        mysql -u root -e "INSERT INTO ps_module (name, active, version) VALUES ('egrow', 1, '1.2.0');"
        echo "✓ Module installed"
    else
        # Module already installed, just activate it
        mysql -u root -e "UPDATE ps_module SET active = 1 WHERE id_module = ${MODULE_ID};"
        echo "✓ Module activated"
    fi
    
    # Clear cache after installation
    clear_cache
}

# Function to uninstall module
uninstall_module() {
    echo "Uninstalling module..."
    
    # Get module ID
    MODULE_ID=$(mysql -u root -e "SELECT id_module FROM ps_module WHERE name = 'egrow';" | tail -n 1)
    
    if [ -n "$MODULE_ID" ]; then
        # Module is installed, deactivate it instead of deleting
        mysql -u root -e "UPDATE ps_module SET active = 0 WHERE id_module = ${MODULE_ID};"
        echo "✓ Module deactivated"
    else
        echo "✓ Module not installed"
    fi
    
    # Clear cache after uninstallation
    clear_cache
}

# Check command line arguments
if [ "$1" == "install" ]; then
    install_module
elif [ "$1" == "uninstall" ]; then
    uninstall_module
else
    echo "Usage: $0 [install|uninstall]"
    exit 1
fi

echo "✅ Operation completed!"
echo "Please refresh your PrestaShop admin panel to see the changes." 
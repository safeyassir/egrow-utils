#!/bin/bash

# Function to clear cache
clear_cache() {
    echo "Clearing cache..."
    
    # Clear PrestaShop cache directories
    rm -rf ../../var/cache/*
    rm -rf ../../var/log/*
    
    # Clear Smarty cache
    rm -rf ../../var/cache/smarty/*
    
    # Clear module cache
    rm -rf ../../var/cache/modules/*
    
    # Clear class index
    rm -f ../../var/cache/class_index.php
    
    # Clear media cache
    rm -rf ../../var/cache/media/*
    
    echo "Cache cleared successfully!"
}

# Main update process
echo "Starting module update to version 1.1.0..."

# Clear cache before update
clear_cache

# Update module version
echo "Updating module to version 1.1.0..."

# Clear cache after update
clear_cache

# Clear
echo "Module update script completed successfully!" 
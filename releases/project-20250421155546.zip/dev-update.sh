#!/bin/bash

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PS_ROOT_DIR="$( cd "$SCRIPT_DIR/../.." && pwd )"

# Function to clear cache
clear_cache() {
    echo "Clearing cache..."
    
    # Clear Smarty cache
    if [ -d "$PS_ROOT_DIR/var/cache" ]; then
        rm -rf "$PS_ROOT_DIR/var/cache"/*
        echo "✓ Smarty cache cleared"
    fi

    # Clear module cache
    if [ -d "$PS_ROOT_DIR/var/cache/prod" ]; then
        rm -rf "$PS_ROOT_DIR/var/cache/prod"/*
        echo "✓ Module cache cleared"
    fi

    # Clear class index
    if [ -f "$PS_ROOT_DIR/var/cache/class_index.php" ]; then
        rm -f "$PS_ROOT_DIR/var/cache/class_index.php"
        echo "✓ Class index cleared"
    fi

    # Clear media cache
    if [ -d "$PS_ROOT_DIR/var/cache/media" ]; then
        rm -rf "$PS_ROOT_DIR/var/cache/media"/*
        echo "✓ Media cache cleared"
    fi

    # Clear template cache
    if [ -d "$PS_ROOT_DIR/var/cache/templates" ]; then
        rm -rf "$PS_ROOT_DIR/var/cache/templates"/*
        echo "✓ Template cache cleared"
    fi
}

# Function to update module files
update_module() {
    echo "Updating module files..."
    
    if [ -d "$SCRIPT_DIR" ]; then
        # Copy files while preserving the module's configuration
        cp -r "$SCRIPT_DIR"/* "$PS_ROOT_DIR/modules/egrow/"
        echo "✓ Module files updated"
    else
        echo "✗ Source module directory not found at $SCRIPT_DIR"
        exit 1
    fi
}

# Function to create upgrade file
create_upgrade_file() {
    echo "Creating upgrade file..."
    
    # Get current version from config.xml
    CURRENT_VERSION=$(grep -oP '(?<=<version><!\[CDATA\[)[0-9.]+(?=\]\]></version>)' "$SCRIPT_DIR/config.xml")
    
    # Create upgrade file
    UPGRADE_FILE="$SCRIPT_DIR/upgrade/upgrade-$CURRENT_VERSION.php"
    if [ ! -f "$UPGRADE_FILE" ]; then
        mkdir -p "$SCRIPT_DIR/upgrade"
        cat > "$UPGRADE_FILE" << EOF
<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_${CURRENT_VERSION//./_}(\$module)
{
    // Clear cache
    Tools::clearCache();
    
    return true;
}
EOF
        echo "✓ Created upgrade file for version $CURRENT_VERSION"
    else
        echo "✓ Upgrade file already exists for version $CURRENT_VERSION"
    fi
}

# Function to upgrade module
upgrade_module() {
    echo "Upgrading module..."
    
    # Get module ID
    MODULE_ID=$(mysql -u root -e "SELECT id_module FROM ps_module WHERE name = 'egrow';" | tail -n 1)
    
    if [ -n "$MODULE_ID" ]; then
        # Upgrade module
        mysql -u root -e "UPDATE ps_module SET version = '${CURRENT_VERSION}' WHERE id_module = ${MODULE_ID};"
        echo "✓ Module upgraded to version $CURRENT_VERSION"
    else
        echo "✗ Module not found in database"
        exit 1
    fi
}

# Main execution
echo "Starting development update..."

# Update module files
update_module

# Create upgrade file
create_upgrade_file

# Clear cache
clear_cache

# Upgrade module
upgrade_module

echo "✅ Development update completed!"
echo "Please refresh your PrestaShop admin panel to see the changes." 
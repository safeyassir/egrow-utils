=== Plugin Name ===
Tags: woocommerce, extension, ecommerce
Stable tag: 1.0
License: MIT
License URI: https://opensource.org/licenses/MIT

eGrow Plugin for WooCommerce

== Description ==

eGrow for WooCommerce is a WooCommerce extension that syncs orders from your WooCommerce store with the eGrow SaaS platform, providing seamless integration and data synchronization.

== Installation ==

1. Drag and drop `egrow.zip` on WordPress /wp-admin/ under Plugins -> Add New -> Upload Plugin.
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0.0 =
* First Version


= 2.0.0 =
* Add Product Sync with eGrow

PS